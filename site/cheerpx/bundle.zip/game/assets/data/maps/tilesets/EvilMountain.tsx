<?xml version="1.0" encoding="UTF-8"?>
<tileset name="EvilMountain" tilewidth="32" tileheight="32">
 <image source="EvilMountain.png" width="512" height="1024"/>
 <tile id="17">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="18">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="19">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="20">
  <properties>
   <property name="damage" value=""/>
  </properties>
 </tile>
 <tile id="21">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="22">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="23">
  <properties>
   <property name="damage" value=""/>
  </properties>
 </tile>
 <tile id="33">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="34">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="35">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="36">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="37">
  <properties>
   <property name="damage" value=""/>
  </properties>
 </tile>
 <tile id="38">
  <properties>
   <property name="damage" value=""/>
  </properties>
 </tile>
 <tile id="39">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="49">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="50">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="51">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="52">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="53">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="81">
  <properties>
   <property name="up" value=""/>
  </properties>
 </tile>
 <tile id="82">
  <properties>
   <property name="up" value=""/>
  </properties>
 </tile>
 <tile id="83">
  <properties>
   <property name="up" value=""/>
  </properties>
 </tile>
 <tile id="113">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="114">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="115">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="116">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="117">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="118">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="122">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="123">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="124">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="125">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="129">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="130">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="131">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="132">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="133">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="134">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="138">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="139">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="140">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="141">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="145">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="146">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="147">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="148">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="149">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="150">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="154">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="155">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="156">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="157">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="161">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="162">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="163">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="164">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="165">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="166">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="170">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="171">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="172">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="173">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="177">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="178">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="179">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="180">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="181">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="182">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="186">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="187">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="188">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="189">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="194">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="197">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="203">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="204">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="209">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="210">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="211">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="212">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="213">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="214">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="511">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
</tileset>
