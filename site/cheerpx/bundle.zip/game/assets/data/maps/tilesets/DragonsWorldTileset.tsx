<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tileSetForest" tilewidth="32" tileheight="32">
 <image source="DragonsWorldTileset.png" trans="ff00ff" width="512" height="1024"/>
 <tile id="80">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="81">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="82">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="96">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="97">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="98">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="99">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="100">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="112">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="113">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="114">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="115">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="116">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="186">
  <properties>
   <property name="damage" value=""/>
  </properties>
 </tile>
 <tile id="196">
  <properties>
   <property name="damage" value=""/>
  </properties>
 </tile>
 <tile id="197">
  <properties>
   <property name="damage" value=""/>
  </properties>
 </tile>
 <tile id="198">
  <properties>
   <property name="damage" value=""/>
  </properties>
 </tile>
 <tile id="199">
  <properties>
   <property name="damage" value=""/>
  </properties>
 </tile>
 <tile id="200">
  <properties>
   <property name="damage" value=""/>
  </properties>
 </tile>
 <tile id="201">
  <properties>
   <property name="damage" value=""/>
  </properties>
 </tile>
 <tile id="202">
  <properties>
   <property name="damage" value=""/>
  </properties>
 </tile>
 <tile id="218">
  <properties>
   <property name="damage" value=""/>
  </properties>
 </tile>
 <tile id="234">
  <properties>
   <property name="damage" value=""/>
  </properties>
 </tile>
</tileset>
