<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tileSetForest" tilewidth="32" tileheight="32">
 <image source="tileForestSketch.png" trans="ff00ff" width="512" height="1024"/>
 <tile id="17">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="18">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="19">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="33">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="34">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="35">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="36">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="37">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="49">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="50">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="51">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="52">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="53">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="86">
  <properties>
   <property name="invisible" value=""/>
  </properties>
 </tile>
 <tile id="88">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="89">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="90">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="91">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="92">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="93">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="94">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="104">
  <properties>
   <property name="water" value=""/>
  </properties>
 </tile>
 <tile id="105">
  <properties>
   <property name="water" value=""/>
  </properties>
 </tile>
 <tile id="109">
  <properties>
   <property name="up" value=""/>
  </properties>
 </tile>
 <tile id="110">
  <properties>
   <property name="up" value=""/>
  </properties>
 </tile>
 <tile id="125">
  <properties>
   <property name="up" value=""/>
  </properties>
 </tile>
 <tile id="126">
  <properties>
   <property name="up" value=""/>
  </properties>
 </tile>
 <tile id="141">
  <properties>
   <property name="up" value=""/>
  </properties>
 </tile>
 <tile id="142">
  <properties>
   <property name="up" value=""/>
  </properties>
 </tile>
 <tile id="149">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="150">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="151">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="157">
  <properties>
   <property name="up" value=""/>
  </properties>
 </tile>
 <tile id="158">
  <properties>
   <property name="up" value=""/>
  </properties>
 </tile>
 <tile id="165">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="166">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="167">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="181">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="182">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="183">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="197">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="198">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="199">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="248">
  <properties>
   <property name="damage" value=""/>
  </properties>
 </tile>
 <tile id="258">
  <properties>
   <property name="damage" value=""/>
  </properties>
 </tile>
 <tile id="259">
  <properties>
   <property name="damage" value=""/>
  </properties>
 </tile>
 <tile id="260">
  <properties>
   <property name="damage" value=""/>
  </properties>
 </tile>
 <tile id="261">
  <properties>
   <property name="damage" value=""/>
  </properties>
 </tile>
 <tile id="262">
  <properties>
   <property name="damage" value=""/>
  </properties>
 </tile>
 <tile id="263">
  <properties>
   <property name="damage" value=""/>
  </properties>
 </tile>
 <tile id="264">
  <properties>
   <property name="damage" value=""/>
  </properties>
 </tile>
 <tile id="268">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="269">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="270">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="271">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="280">
  <properties>
   <property name="damage" value=""/>
  </properties>
 </tile>
 <tile id="284">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="285">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="286">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="287">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="288">
  <properties>
   <property name="up" value=""/>
  </properties>
 </tile>
 <tile id="289">
  <properties>
   <property name="up" value=""/>
  </properties>
 </tile>
 <tile id="290">
  <properties>
   <property name="up" value=""/>
  </properties>
 </tile>
 <tile id="296">
  <properties>
   <property name="damage" value=""/>
  </properties>
 </tile>
 <tile id="300">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="301">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="302">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="303">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="316">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="317">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="318">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="319">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="332">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="333">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="334">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="335">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="349">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="350">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="352">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="353">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="354">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="361">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="362">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="363">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="364">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="365">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="366">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="367">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="368">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="369">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="370">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="377">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="378">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="379">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="380">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="383">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="384">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="385">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="386">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="393">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="394">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="395">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="396">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="397">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="398">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="399">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="400">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="401">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="402">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="409">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="410">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="411">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="428">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="429">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="430">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="431">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="461">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="462">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="463">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="464">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="465">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="466">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="480">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="481">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="482">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="483">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="484">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="511">
  <properties>
   <property name="invisible" value=""/>
  </properties>
 </tile>
</tileset>
