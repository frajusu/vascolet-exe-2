<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Castle" tilewidth="32" tileheight="32">
 <image source="Castle.png" width="512" height="1024"/>
 <tile id="17">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="18">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="19">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="33">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="34">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="35">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="49">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="50">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="51">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="65">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="66">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="67">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="81">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="82">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="83">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="98">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="113">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="114">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="115">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="257">
  <properties>
   <property name="damage" value=""/>
  </properties>
 </tile>
 <tile id="258">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="259">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="260">
  <properties>
   <property name="damage" value=""/>
  </properties>
 </tile>
 <tile id="273">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="274">
  <properties>
   <property name="damage" value=""/>
  </properties>
 </tile>
 <tile id="275">
  <properties>
   <property name="damage" value=""/>
  </properties>
 </tile>
 <tile id="276">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
 <tile id="511">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
</tileset>
