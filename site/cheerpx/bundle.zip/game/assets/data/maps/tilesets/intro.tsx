<?xml version="1.0" encoding="UTF-8"?>
<tileset name="intro" tilewidth="32" tileheight="32">
 <image source="intro.png" width="512" height="1024"/>
 <tile id="0">
  <properties>
   <property name="invisible" value=""/>
  </properties>
 </tile>
 <tile id="511">
  <properties>
   <property name="solid" value=""/>
  </properties>
 </tile>
</tileset>
